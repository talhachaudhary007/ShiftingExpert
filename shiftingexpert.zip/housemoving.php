<?php
include "header.php";
?>

<!-- Header Start -->
<div class="jumbotron jumbotron-fluid mb-5">
    <div class="container text-center py-5">
        <h1 class="text-white display-3 pb-2">Shifting Expert</h1>
        <div class="d-inline-flex align-items-center text-white">
            <p class="m-0"><a class="text-white" href="">Home</a></p>
            <i class="fa fa-circle px-3"></i>
            <p class="m-0">Services</p>
            <i class="fa fa-circle px-3"></i>
            <p class="m-0">House Moving</p> 

        </div>
    </div>
</div>
<!-- Header ends -->

<!-- Blog Start -->
<div class="blog-container mt-5">
    <div class="row">



        <!-- Blog Grid Start -->
        <div class="col-lg-8">
            <div class="row">
                <div class="col-md-12 mb-3">
                    <h5 class="text-primary font-weight-bold">House Moving Services in Dubai:</h5>
                    <h2 class="font-weight-bold mb-3">Ready for an upgrade? Let handle your move for a stress-free transition</h2>
                    <p>  As a top mover's shifting expert company in Dubai, we're here to provide expert house moving services with the highest standards, ensuring your peace of mind. We're more than movers, we're your complete moving partners in Dubai. Rely on our professional packing services for a secure and smooth transition to your new home. <b>House Moving Services in Dubai Seamless Solutions from Your Trusted shifting Expert Movers & Packers</b> Look no further! At Shifting Expert, we take pride in being your trusted guide to a seamless and stress-free relocation experience. Get Full Door-to-Door House Moving Services in Dubai</p>
                    <h2 class="font-weight-bold mb-3">The Benefit of Local Knowledge</h2>
                    <p>Being a local moving business in Dubai, we take use of our thorough knowledge of the structure of  city to make your move smooth. Our familiarity with parking restrictions, traffic patterns, and logistical challenges allows us to plan efficient routes and navigate seamlessly. This local knowledge ensures a hassle-free moving experience, saving your time and minimizing stress.</p>
                    <h2 class="font-weight-bold mb-3">Shifting Expert provide a Stress-Free House Moving Solution</h2>
                    <p>From carefully packing your belongings to efficiently unpacking them at your new destination, we've got every step of your house moving journey covered.
                    As professional movers and packers in Dubai with over 25+ years of industry expertise, we provide complete solutions to fulfil your requirements for moving homes.</p>
                    <div class="position-relative">
                        <img class="img-fluid w-100" src="img/blog3.png" alt="">
                        <div class="position-absolute bg-primary d-flex flex-column align-items-center justify-content-center rounded-circle"
                            style="width: 60px; height: 60px; bottom: -30px; right: 30px;">
                            <h4 class="font-weight-bold mb-n1">01</h4>
                            <small class="text-white text-uppercase">Jan</small>
                        </div>
                    </div>
                    <div class="bg-secondary mb-3" style="padding: 30px;">

                        <h4 class="font-weight-bold mb-3">Why Choose Our House Moving Services</h4>
                        <p> <b>Professional Knowledge </b>With the expertise to manage the complicated processes of home relocations, our team of professional experts in Dubai can guarantee an effortless move for you and your staff. <b>Efficient Planning and Execution</b> We ensure your move is well-organized and timely, making the entire process hassle-free. <b>Equipment and Resources</b> Equipped with the right tools, we handle moves of any size, ensuring safe transportation and minimizing the risk of accidents or damage to your belongings.
                        </p>
                        <h5 class="font-weight-bold">Customized Solutions</h5>
                        <p>We understand that each house move is different. Our flexible staff offers customized choices to meet the various demands and specifications of our customers. <b>Competitive Pricing</b> With our house moving packages, you may get first-rate services that are reasonably priced. We take pride in providing solutions that are affordable without compromising quality.</p>
                    </div>
                </div>
                <div class="col-md-12 mb-3">
                    <div class="position-relative">
                        <h5 class="text-primary font-weight-bold">Comprehensive Services</h5>
                        <h1 class="font-weight-bold mb-3">Competitive Pricing</h1>
                        <p> With our house moving packages, you may get first-rate services that are reasonably priced. We take pride in providing solutions that are affordable without compromising quality. <b>Comprehensive Services</b> From packing and loading to unpacking and unloading, our full door-to-door services cover every aspect of your house move. We are not just movers; we are your reliable partners throughout the process.</p>
                        <h5 class="font-weight-bold">Expert Carpenters Supporting</h5>
                        <p>Because to the expertise of our team's carpenters, furniture will be constructed and deconstructed during the move without any delay. Save time and effort while we carefully manage the logistics.</p>
                        <img class="img-fluid w-100" src="img/blog2.png" alt="">
                        <div class="position-absolute bg-primary d-flex flex-column align-items-center justify-content-center rounded-circle"
                            style="width: 60px; height: 60px; bottom: -30px; right: 30px;">
                            <h4 class="font-weight-bold mb-n1">06</h4>
                            <small class="text-white text-uppercase">Jan</small>
                        </div>
                    </div>
                    <div class="bg-secondary mb-3" style="padding: 30px;">

                        <h4 class="font-weight-bold mb-3">Quality You Can Trust</h4>
                        <p>Our packing services come with a guarantee of quality in Dubai. We use heigh quality materials to ensure your belongings are well-protected during transit. Your satisfaction is our top priority, and we go the extra mile to provide services you can trust.</p>
                        <h5 class="font-weight-bold">Trustworthy Team</h5>
                        <p>Our team isn't just professional; we're trustworthy friends you can rely on in Dubai. Building long-lasting relationships is our aim, and we achieve this by providing quality service and sticking to an affordable price. You can count on us to be reliable partners throughout your move.
                        </p>


                    </div>
                </div>
                <div class="col-md-12 mb-3">
                    <div class="position-relative">
                        <h5 class="text-primary font-weight-bold">Optional Protection Against Risk:</h5>
                        <h1 class="font-weight-bold mb-3">Opt for Our Liability Package:</h1>
                        <p>We care about your belongings! Choose our liability package for added protection during your move. This extra coverage ensures your items are safe and secure, offering peace of mind in case of any unexpected events.
                        </p>
                        <h5 class="font-weight-bold">Cheapest House Moving in Dubai</h5>
                        <p> <b>Discover the most budget-friendly house moving services in Dubai with us!</b> We prioritize affordability without compromising quality. Our pride lies in providing customized solutions that fit your budget, ensuring you experience top-notch service without breaking the bank. Move with us for a cost-effective and reliable solution tailored just for you.</p>
                        <img class="img-fluid w-100" src="img/blog1.png" alt="">
                        <div class="position-absolute bg-primary d-flex flex-column align-items-center justify-content-center rounded-circle"
                            style="width: 60px; height: 60px; bottom: -30px; right: 30px;">
                            <h4 class="font-weight-bold mb-n1">18</h4>
                            <small class="text-white text-uppercase">Jan</small>
                        </div>
                    </div>
                    <div class="bg-secondary mb-3" style="padding: 30px;">
                        <h5 class="font-weight-bold text-primary text-center">Best Movers & Packers</h5>
                        <h1 class="font-weight-bold mb-5 text-center">Best House Moving in Dubai</h1>
                        <h5 class="font-weight-bold mb-3">1. Expert Carpenters Supporting </h5>
                            <p>Shifting Expert, the best house moving company in Dubai, has built a stellar reputation in over 25 years. Count on us for a smooth and efficient moving experience. We ensure your comfort and reliability throughout the process, making your move stress-free and enjoyable.</p>
                    
                        <h5 class="font-weight-bold mb-3">2. Affordable Pricing</h5>
                        <p> <b> Worried about hidden costs? </b> With Shifting Expert, you get transparent and affordable pricing. What you see is what you get, making your move stress-free and budget friendly.</p>
                        <h5 class="font-weight-bold mb-3">3. What are the functions of movers?</h5>
                        <p>A mover can transfer furniture and belongings from one point to another. The essential duty
                            of movers is to ensure that all the items are placed safely without any damage. Movers are
                            physically fit and are responsible professionals who pack items efficiently.</p>
                        <h5 class="font-weight-bold mb-3">4. Movers and Packers in Dubai:</h5>
                        <p>We are not just movers; we are your trusted packers too. Our professional packing ensures the safety and security of your belongings throughout the journey.</p>
                        <h5 class="font-weight-bold mb-3">5. Relocate stress-free with Shifting Expert</h5>
                        <p>your reliable partner for house moving services in Dubai. Contact us today for a smooth transition to your new home!</p>
                    </div>
                </div>
            </div>

        </div>
        <!-- Blog Grid End -->

                <!-- Sidebar Start -->
                <div class="col-lg-4 mt-5 mt-lg-0">
                    <!-- Search Form Start -->
                    <div class="mb-5">
                        <div class="bg-secondary" style="padding: 30px;">
                            <div class="input-group">
                                <input type="text" class="form-control border-0 p-4" placeholder="Search here...">
                                <div class="input-group-append">
                                    <span class="input-group-text bg-primary border-primary text-white"><i
                                            class="fa fa-search"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Search Form End -->
        
        
                    <!-- Recent Post Start -->
                    <div class="mb-5">
                        <h3 class="mb-4">Recent Posts</h3>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/1.png" style="width: 80px; height: 80px; object-fit: cover;" alt="">
                            <a href="packingservices.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Looking for expert packing services to ensure hassle-free relocation
                            </a>
                        </div>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/blog-2.jpg" style="width: 80px; height: 80px; object-fit: cover;"
                                alt="">
                            <a href="storageservices.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Running out of space? Store items with us until you're ready to move into a new house
                            </a>
                        </div>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/blog1.png" style="width: 80px; height: 80px; object-fit: cover;"
                                alt="">
                            <a href="housemoving.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Planning to move your home? Need reliable house moving services
                            </a>
                        </div>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/3.png" style="width: 80px; height: 80px; object-fit: cover;" alt="">
                            <a href="villamoving.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Interested in seamless villa moving services for a stress-free experience
                            </a>
                        </div>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/2.png" style="width: 80px; height: 80px; object-fit: cover;" alt="">
                            <a href="residentialmoving.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Seeking expert residential moving services for a comfortable transition
                            </a>
                        </div>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/blog-1.jpg" style="width: 80px; height: 80px; object-fit: cover;"
                                alt="">
                            <a href="commercialmoving.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Expanding your business? In need of efficient commercial moving services for relocation
                            </a>
                        </div>
                    </div>
                    <!-- Recent Post End -->
        
                    <!-- Category Start -->
                    <div class="mb-5">
                        <h3 class="mb-4">Our Regions</h3>
                        <div class="bg-secondary" style="padding: 30px;">
                            <ul class="list-inline m-0">
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="dubai.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Dubai
                                    </a>
                                    <span class="badge badge-secondary badge-pill">150</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="abudhabi.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Abu Dhabi
                                    </a>
                                    <span class="badge badge-secondary badge-pill">131</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="sharjah.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Sharjah
                                    </a>
                                    <span class="badge badge-secondary badge-pill">78</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="ajman.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Ajman
                                    </a>
                                    <span class="badge badge-secondary badge-pill">56</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="fujairah.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Fujairah
                                    </a>
                                    <span class="badge badge-secondary badge-pill">152</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="alain.php"><i class="fa fa-angle-right text-primary mr-2"></i>Al
                                        Ain
                                    </a>
                                    <span class="badge badge-secondary badge-pill">86</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="ajman.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Ajman
                                    </a>
                                    <span class="badge badge-secondary badge-pill">126</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="khorfakkan.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Khorfakkan
                                    </a>
                                    <span class="badge badge-secondary badge-pill">90</span>
                                </li>
                                <li class="py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="rasalkhaimah.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Ras Al Khaimah
                                    </a>
                                    <span class="badge badge-secondary badge-pill">118</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- Category End -->
        
                    <!-- Image Start -->
                    <div class="mb-5">
                        <img src="img/blog-1.jpg" alt="" class="img-fluid">
                    </div>
                    <!-- Image End -->
        
                    <!-- Tags Start -->
                    <div class="mb-5">
                        <h3 class="mb-4">Tag Cloud</h3>
                        <div class="d-flex flex-wrap m-n1">
                            <a href="moving" class="btn btn-secondary m-1">Moving</a>
                            <a href="" class="btn btn-secondary m-1">Shifting</a>
                            <a href="packingservices.php" class="btn btn-secondary m-1">Packing</a>
                            <a href="storageservices.php" class="btn btn-secondary m-1">Storage</a>
                            <a href="officerelocation.php" class="btn btn-secondary m-1">Office Relocation</a>
                            <a href="cheapmovers.php" class="btn btn-secondary m-1">Cheap Movers</a>
                        </div>
                    </div>
                    <!-- Tags End -->
        
        
                    <!-- Image Start -->
                    <div class="mb-5">
                        <img src="img/blog-2.jpg" alt="" class="img-fluid">
                    </div>
                    <!-- Image End -->
        
        
                    <!-- Recommended Category Start -->
                    <div class="mb-5">
                        <h3 class="mb-4">Recommended Posts</h3>
                        <div class="bg-secondary" style="padding: 30px;">
                            <ul class="list-inline m-0">
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="packingservices.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Packing Services
                                    </a>
                                    <span class="badge badge-secondary badge-pill">150</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="housemoving.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>House Moving
                                    </a>
                                    <span class="badge badge-secondary badge-pill">131</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="villamoving.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Villa Moving
                                    </a>
                                    <span class="badge badge-secondary badge-pill">78</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="residentialmoving.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Residential Moving
                                    </a>
                                    <span class="badge badge-secondary badge-pill">126</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="commercialmoving.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Commercial Moving
                                    </a>
                                    <span class="badge badge-secondary badge-pill">80</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="officerelocation.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Office Relocation
                                    </a>
                                    <span class="badge badge-secondary badge-pill">178</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="corporaterelocation.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Corporate Relocation
                                    </a>
                                    <span class="badge badge-secondary badge-pill">136</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="appartmentmoving.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Appartment Moving
                                    </a>
                                    <span class="badge badge-secondary badge-pill">150</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="furnituremoving.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Furniture Moving
                                    </a>
                                    <span class="badge badge-secondary badge-pill">56</span>
                                </li>
                                <li class="py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="equipmentmoving.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>IT Equipment Moving
                                    </a>
                                    <span class="badge badge-secondary badge-pill">98</span>
                                </li>
        
                            </ul>
                        </div>
                    </div>
                    <!--Recommended Category End -->
        
        
                    <!-- Plain Text Start -->
                    <div>
                        <h3 class="mb-4">Shifting Expert</h3>
                        <div class="bg-secondary text-center" style="padding: 20px; text-align: justify;">
                            <p>We're here to make moving easy for you. Whether it's your home or office, our team ensures a
                                smooth and stress-free relocation. </p>
                            <p><i class="fa fa-angle-right text-primary"></i><i class="fa fa-angle-right text-primary mr-2"></i>
                                From packing to storage, we've got you covered. Trust us for a hassle-free moving experience</p>
                            <a href="contact.php" class="btn btn-primary py-2 px-4">Contact Us</a>
                        </div>
                    </div>
                    <!-- Plain Text End -->
        
        
                    <!-- Image Start -->
                    <div class="my-5">
                        <img src="img/blog-1.jpg" alt="" class="img-fluid">
                    </div>
                    <!-- Image End -->
        
        
                    <!-- Recommended Articles Start -->
                    <div class="mb-5">
                        <h3 class="mb-4">Recommended Articles</h3>
                        <div class="bg-secondary" style="padding: 30px;">
                            <ul class="list-inline m-0">
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="dubai.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Movers and Packers In Dubai
                                    </a>
                                    <span class="badge badge-secondary badge-pill">150</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="packingservices.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Packers UAE
        
                                    </a>
                                    <span class="badge badge-secondary badge-pill">131</span>
                                </li>
        
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="housemoving.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>House Shifting Sharjah
                                    </a>
                                    <span class="badge badge-secondary badge-pill">56</span>
                                </li>
                                <li class="mb-1 py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="storageservices.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Storage Solutions UAE
                                    </a>
                                    <span class="badge badge-secondary badge-pill">127</span>
                                </li>
                                <li class="py-2 px-3 bg-light d-flex justify-content-between align-items-center">
                                    <a class="text-dark" href="corporaterelocation.php"><i
                                            class="fa fa-angle-right text-primary mr-2"></i>Relocation Dubai
                                    </a>
                                    <span class="badge badge-secondary badge-pill">98</span>
                                </li>
        
                            </ul>
                        </div>
                    </div>
                    <!-- Recommended Articles End -->
        
        
                    <!-- Recent Post Start -->
                    <div class="mb-5">
                        <h3 class="mb-4">Recent Posts</h3>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/1.png" style="width: 80px; height: 80px; object-fit: cover;" alt="">
                            <a href="officerelocation.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Planning an office move? Require professional office relocation services
                            </a>
                        </div>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/3.png" style="width: 80px; height: 80px; object-fit: cover;" alt="">
                            <a href="corporaterelocation.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Considering corporate relocation? Need services to minimize business disruptions
                            </a>
                        </div>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/6.png" style="width: 80px; height: 80px; object-fit: cover;" alt="">
                            <a href="apartmentmoving.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Moving to a new apartment? Looking for reliable apartment moving services
                            </a>
                        </div>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/blog2.png" style="width: 80px; height: 80px; object-fit: cover;"
                                alt="">
                            <a href="furnituremoving.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Updating your furniture? Interested in safe and efficient furniture moving
                            </a>
                        </div>
                        <div class="d-flex mb-2">
                            <img class="img-fluid" src="img/1.png" style="width: 80px; height: 80px; object-fit: cover;" alt="">
                            <a href="equipmentmoving.php"
                                class="d-flex align-items-center bg-secondary text-dark blogtext-decoration-none px-3"
                                style="height: 80px;">
                                Upgrading your tech IT setup? Require specialized IT equipment moving services
                                storageservices.php
                            </a>
                        </div>
                    </div>
                    <!-- Recent Post End -->
        
        
        </div>
        <!-- Sidebar End -->

    </div>

    <div class="row">
        <div class="col-12">
            <nav aria-label="Page navigation">
                <ul class="pagination pagination-lg justify-content-center mb-0">
                    <li class="page-item">
                        <a class="page-link" href="storageservices.php" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                            <span class="sr-only">Previous</span>
                        </a>
                    </li>
                    <li class="page-item"><a class="page-link" href="packingservices.php">1</a></li>
                    <li class="page-item"><a class="page-link" href="storageservices.php">2</a></li>
                    <li class="page-item active"><a class="page-link" href="housemoving.php">3</a></li>
                    <li class="page-item"><a class="page-link" href="villamoving.php">4</a></li>
                    <li class="page-item">
                        <a class="page-link" href="villamoving.php" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                            <span class="sr-only">Next</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
<!-- Blog End -->



<?php
include "footer.php";
?>